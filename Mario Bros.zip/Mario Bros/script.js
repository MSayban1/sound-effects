const mario = document.getElementById('mario');
const enemy = document.getElementById('enemy');
const coin = document.getElementById('coin');

// Sound effects
const jumpSound = document.getElementById('jump-sound');
const coinSound = document.getElementById('coin-sound');
const enemyHitSound = document.getElementById('enemy-hit-sound');
const backgroundMusic = document.getElementById('background-music');

// Play background music
backgroundMusic.play();

let marioBottom = 100;
let isJumping = false;
let isGameOver = false;
let score = 0;

// Mario Jump with Sound
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowUp' && !isJumping) {
        isJumping = true;
        jumpSound.play(); // Play jump sound
        let jumpInterval = setInterval(() => {
            if (marioBottom >= 250) {
                clearInterval(jumpInterval);
                let fallInterval = setInterval(() => {
                    if (marioBottom <= 100) {
                        clearInterval(fallInterval);
                        isJumping = false;
                    }
                    marioBottom -= 5;
                    mario.style.bottom = marioBottom + 'px';
                }, 20);
            }
            marioBottom += 5;
            mario.style.bottom = marioBottom + 'px';
        }, 20);
    }
});

// Enemy Movement with Collision Sound
let enemyPosition = 400;
let enemyInterval = setInterval(() => {
    if (enemyPosition <= 0) {
        enemyPosition = 400;
    } else {
        enemyPosition -= 5;
        enemy.style.left = enemyPosition + 'px';
    }

    // Collision Detection
    if (
        enemyPosition < 100 &&
        enemyPosition > 50 &&
        marioBottom <= 150
    ) {
        clearInterval(enemyInterval);
        isGameOver = true;
        enemyHitSound.play(); // Play collision sound
        alert('Game Over!');
    }
}, 50);

// Coin Collection with Sound
let coinPosition = 300;
let coinInterval = setInterval(() => {
    if (
        coinPosition < 100 &&
        coinPosition > 50 &&
        marioBottom >= 150
    ) {
        score += 10;
        coinSound.play(); // Play coin collection sound
        alert('Coin Collected! Score: ' + score);
        coin.style.left = '-100px'; // Move coin out of view
    }
}, 50);

